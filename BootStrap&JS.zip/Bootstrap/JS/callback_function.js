function calculate(num1,num2,operation,callback)
{
    const result = operation(num1,num2);
    callback(result);
}

function printResult(result)
{
    console.log(`the result is ${result}`);
}

calculate(10,5,(n1,n2)=>n1+n2,printResult,printResult)



