function isArmstrongNumber(num) {
    // Convert the number to a string to get the number of digits
    const numStr = num.toString();
    const numDigits = numStr.length;
  
    // Calculate the sum of each digit raised to the power of the number of digits
    let sum = 0;
    for (let i = 0; i < numDigits; i++) {
      const digit = parseInt(numStr[i]);
      sum += Math.pow(digit, numDigits);
    }
  
    // Return true if the sum is equal to the original number, false otherwise
    return sum === num;
  }
  
  // Example usage
  console.log(isArmstrongNumber(153)); // true
  console.log(isArmstrongNumber(370)); // true
  console.log(isArmstrongNumber(9474)); // true
  console.log(isArmstrongNumber(9475)); // false
  