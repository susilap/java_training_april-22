var acc_bal = 15000;

var withdraw_amt=15000;

if(acc_bal>=withdraw_amt)
{
   
    var aval_bal= acc_bal-withdraw_amt;
    console.log("Transaction is Successfull !... Available Balance is:"+aval_bal);

}else{

    console.log("Insufficient Fund .... Available Balance is:"+acc_bal);
}
