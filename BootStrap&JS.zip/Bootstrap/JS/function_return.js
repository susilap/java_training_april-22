
function calc(a,b)
{
    return a*b;
}

let res=calc(87,34);

console.log(res);

console.log(calc(6,3));console.log(calc(56,38));