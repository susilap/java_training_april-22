function sum(...numbers)
{
    let result =0;
    for(let number of numbers)
    {
        result+=number;

    }
    return result;
}


console.log(sum(4,5));
console.log(sum(6,76,34));
console.log(sum(32,56,34,76));