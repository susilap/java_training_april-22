
//traditional function

function add(x,y)
{
    return x+y;
}

console.log("Traditional function:"+add(87,9));
//arrow function

var res=(a,b) =>a+b;
console.log("Arrow function:"+res(87,9));