function Person(name,age)
{
    this.name=name;
    this,age=age;
}
Person.prototype.city="texas";

Person.prototype.greet = ()=> console.log(`Hi ... name is ${this.name} and age is ${this.age} from ${this.city}`)



const obj = new Person('john',25);
obj.greet();
console.log(obj.city);