function outerFunction()
{
    const outerVariable =' i am from the outer function';

    function innerFunction()
    {
        console.log(outerVariable);
    }
    return innerFunction;
}

const innerFun = outerFunction();
innerFun();

//innerFunction();