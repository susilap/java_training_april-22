const readline = require('readline');

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Prompt user for input
rl.question("Please enter your name: ", function(name) {
  rl.question("Please enter your hourly rate: ", function(hourlyRate) {
    rl.question("Please enter the number of hours worked: ", function(hoursWorked) {

      // Parse input as numbers
      hourlyRate = Number(hourlyRate);
      hoursWorked = Number(hoursWorked);

      // Calculate gross pay
      const grossPay = hourlyRate * hoursWorked;

      // Calculate deductions
      const taxRate = 0.1; // 10% tax rate
      const taxAmount = grossPay * taxRate;
      const netPay = grossPay - taxAmount;

      // Generate payslip
      const payslip = `
        Name: ${name}
        Hours Worked: ${hoursWorked}
        Hourly Rate: $${hourlyRate.toFixed(2)}
        Gross Pay: $${grossPay.toFixed(2)}
        Tax: $${taxAmount.toFixed(2)}
        Net Pay: $${netPay.toFixed(2)}
      `;

      // Display payslip
      console.log(payslip);

      // Close readline interface
            rl.close();
    });
  });
});

