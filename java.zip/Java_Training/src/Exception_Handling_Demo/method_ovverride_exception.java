package Exception_Handling_Demo;
import java.io.*;
class Parent
{
	void msg()throws IOException
	{
		System.out.println("Parent Method");
	}
}
class Child extends Parent
{
	void msg() throws IOException
	{
		super.msg();
		System.out.println("Child Method");
	}
}
public class method_ovverride_exception  {

	public static void main(String[] args)
	{
		Child obj= new Child();
		try {
			
		obj.msg();
		
		}catch(IOException e)
		{
			System.out.println(e);
		}

	}

}
