package Exception_Handling_Demo;

class Parent2
{
	void msg() throws Exception
	{
		System.out.println("Parent Method");
	}
}
class Child2 extends Parent2
{
	void msg()  throws ArithmeticException
	{
		
		System.out.println("Child Method");
	}
}

public class method_override2 {

	public static void main(String[] args)
	{
		Child2 c =new Child2();
		
		c.msg();
		// TODO Auto-generated method stub

	}

}
