package Exception_Handling_Demo;

public class finalizer_ex {

	public static void main(String[] args)
	{
		finalizer_ex o  = new finalizer_ex();
		System.out.println("Hash code is:"+o.hashCode());
		o =null;
		System.gc();
		System.out.println("End of garpage collection");
		System.out.println("Hash code is:"+o.hashCode());

	

	}
	
	protected void finalize()
	{
		System.out.println("Calling finalize method");
	}

}
