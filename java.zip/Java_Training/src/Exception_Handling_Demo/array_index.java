package Exception_Handling_Demo;

public class array_index {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		int regno[] =new int[10];
		
		regno[0]=10;
		System.out.println("0th index is:"+regno[0]);

		try {
		regno[10]=90;
		System.out.println("10th index is:"+regno[10]);
		}catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		
		System.out.println("Rest of the Code");


	}

}
