package Exception_Handling_Demo;

import java.io.IOException;
class Parent1
{
	void msg()
	{
		System.out.println("Parent Method");
	}
}
class Child1 extends Parent1
{
	void msg() throws ArithmeticException
	{
		super.msg();
		System.out.println("Child Method");
	}
}

public class method_override1 {

	public static void main(String[] args) 
	{
		
	Child1 c =new Child1();
	c.msg();

	}

}
