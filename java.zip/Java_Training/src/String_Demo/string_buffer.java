package String_Demo;

public class string_buffer {

	public static void main(String[] args) {
		
		StringBuffer s =new StringBuffer("Hello World");
		
		System.out.println(s);

	}

}
