package String_Demo;

public class string_concatenation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("hello"+"world");
		System.out.println(50+70);
		System.out.println("hello"+50);
		System.out.println("hello"+60+40);
		System.out.println(60+40+"hello"+60+40);

	}

}
