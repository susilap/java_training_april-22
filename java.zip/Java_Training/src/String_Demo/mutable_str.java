package String_Demo;

public class mutable_str {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuilder s = new StringBuilder("sachin");
		s.append("   tendulkar");
		System.out.println(s);


	}

}
