package String_Demo;

public class java_string {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		String s1 =new String("Hello World");
		
		StringBuffer s2 =new StringBuffer("Hello Java");
		
		StringBuilder s3 =new StringBuilder("Hello String");
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

	}

}
