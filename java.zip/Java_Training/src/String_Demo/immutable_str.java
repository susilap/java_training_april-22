package String_Demo;

public class immutable_str {

	public static void main(String[] args) {
		
		String s = "sachin"; // sachin -> String Constant Pool
		s.concat("tendulkar"); //  trying to change
		System.out.println(s);
		

	}

}
