package String_Demo;

public class str_cmp2 {

	public static void main(String[] args) {
		
		String str1="Sachin";
		String str2="Sachin";
		String str3=new String("Sachin");
		
		System.out.println(str1==str2); //t
		System.out.println(str1==str3); //f
		

	}

}

