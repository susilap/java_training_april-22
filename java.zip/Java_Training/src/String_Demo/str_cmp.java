package String_Demo;

public class str_cmp {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String s1="Sachin";
		String s2="Sachin";
		String s3=new String("Sachin");
		String s4="Saurav";
		String s5="SACHIN";
		
		System.out.println(s1.equals(s2)); // t
		System.out.println(s1.equals(s3));// t
		System.out.println(s1.equals(s4)); // f
		System.out.println(s1.equalsIgnoreCase(s5)); // t

	}

}
