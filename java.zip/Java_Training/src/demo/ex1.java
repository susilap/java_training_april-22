package demo;
import basics.*;

public class ex1 {

	public static void main(String[] args) {
		armstrong_num a =new armstrong_num();
		a.arm_strong(153);
		a.arm_strong(255);
		a.arm_strong(470);
		a.arm_strong(407);
		
		customer obj =new customer(101,"Arjun","chennai");
		obj.display();
		
		obj.id=111;
		System.out.println(obj.id);
		customer.name="manju";
		System.out.println(customer.name);
		customer.address="Delhi";
		System.out.println(customer.address);
		
		System.out.println(obj.aadhar);
		//obj.aadhar=111869555554l;
		System.out.println(obj.aadhar);


		
		customer obj1 =new customer(102,"Anu","Bangalore");
		obj1.display();




	}

}
