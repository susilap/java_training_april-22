package basics;

import java.util.Scanner;

public class userinput {

	public static void main(String[] args) 
	{
		Scanner s =new Scanner(System.in);
		
		System.out.println("Enter the Employee No of Employees");
		int nos =s.nextInt();
		
		for(int i=0;i<nos;i++)
		{
		System.out.println("Enter the Employee Name");
		String name =s.next();
		
		System.out.println("Enter the Employee Number");
		int emp_no =s.nextInt();
		
		System.out.println("Enter the Employee Salary");
		float salary =s.nextFloat();
		
		float da=salary*15/100;
		float hra=30*salary/100;
		
		float pf=12*salary/100;
		float esi=15*salary/100;
		float tot_deduction =pf+esi;
		
		float tot_earnings=salary+da+hra;
		float gross_pay=tot_earnings-tot_deduction;
		
		System.out.println(" ==============================================================");
		System.out.println(" Employee Details");
		System.out.println(" ==============================================================");
		System.out.println(" Employee Number:"+emp_no);
		System.out.println(" Employee Name:"+name);
		System.out.println(" Employee Salary:"+salary);
		System.out.println(" Total Earnings:"+tot_earnings);
		System.out.println(" Total Deduction :"+tot_deduction);
		System.out.println(" Net Salary:"+gross_pay);
		System.out.println(" ==============================================================");
		s.close();
		}

	}

}
