package basics;

public class if_elseif_ex
{
	public static void main(String args[])
	{
		int avg=85;
		
		if(avg>=85)
		{
			System.out.println("first class");
		}
		
		else if(avg>=80 && avg<85)
		{
			System.out.println("Second class");

			
		}
		else
		{
			System.out.println("Third class");

		}
	
		
	}


}
