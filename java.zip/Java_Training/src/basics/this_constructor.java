package basics;

class C
{
	C()
	{
		System.out.println("from current class constructor");
	}
	
	C(int x)
	{
		this();
		System.out.println("X ="+x);
	}
	C(int x,int y)
	{
		this(20);
		System.out.println(x+y);
	}
}
public class this_constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C obj =new C(10,50);
	}

}
