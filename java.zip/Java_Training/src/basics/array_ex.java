package basics;

public class array_ex 
{
	public static void main(String args[])
	{
		int a[] =new int[10];
		
		a[0]=34;
		a[1]=54;
		a[2]=65;
		a[3]=74;
		a[4]=87;
		a[5]=90;
		a[6]=43;
		a[7]=42;
		a[8]=65;
		a[9]=76;
		
		
		System.out.println("4th index"+a[4]);	

		
		for(int i=0;i<10;i++) 
		{
		System.out.println(i+"th index"+a[i]);	
		}
		
		System.out.println("Using for each loop");	

		for(int j:a)
		{
			System.out.println(j);	

			
		}
	}
	

}
