package basics;

public class If_ex 
{
	public static void main(String args[])
	{
		int avg=75;
		
		if(avg>=85)
		{
			System.out.println("first class");
		}
		
				else
		{
			System.out.println("Third class");

		}
	
		
	}

}
