package basics;

abstract class bank
{
	bank()  // constructor
	{
		System.out.println("Abstract class constructor called");
	}
void display() // non-abstract method
{
	System.out.println("Non Abstract Method from Abstract Class");
}

abstract int roi(); //abstract method
}

//abstract class demo extends bank
//{
// abstract void abs_demo();	
//}


class sbi extends bank
{

	
	int roi() 
	{
		return 10;
	}

	
	void abs_demo() {
	System.out.println("Anstract method");
		
	}
	
}

class icici extends bank
{

	
	int roi() 
	{
		return 13;
	}
	
}

class hdfc extends bank
{

	
	int roi() 
	{
		return 15;
	}
	
}


public class abstract_class {

	public static void main(String[] args)
	{
		
	sbi s =new sbi();
	
	icici i  = new icici();
	
	hdfc h =new hdfc();
	
	s.abs_demo();
	System.out.println("SBI Rate Of Interest :"+s.roi());
	System.out.println("ICICI Rate Of Interest :"+i.roi());
	System.out.println("HDFC Rate Of Interest :"+h.roi());

	
	}

}
