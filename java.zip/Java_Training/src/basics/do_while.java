package basics;

public class do_while 
{
	public static void main(String args[])
	{
		int i=0,n=10;
		
		do
		{
			System.out.println("Hello World"+i);
			i++;
		}while(i<=n);
	}
}
