package basics;

class animal1
{
	
	void eat()
	{
		System.out.println("eating....");
	}
}
class dog1 extends animal1
{
	void bark()
	{
		System.out.println("barking....");

	}
	
	void eat()
	{
		System.out.println("playing....");
		
	}
	
	void work()
	{
		super.eat();
		bark();
	}
}

public class parent_method_usingsuper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog1 d =new dog1();
		d.work();
		d.eat();
		
	}

}
