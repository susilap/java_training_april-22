package basics;

class stu8 //product
{
	private int regno,mark; //pid,price
	private String name; //name
	
	public void set_regno(int regno)
	{
		this.regno=regno;
		
	}
	
	public void set_mark(int mark)
	{
		this.mark=mark;
		
	}
	
	public void set_name(String name)
	{
		this.name=name;
		
	}
	
	public int get_regno()
	{
		return this.regno;
	}
	
	public int get_mark()
	{
		return this.mark;
	}
	
	public String get_name()
	{
		return this.name;
	}
}
public class encapsulation {

	public static void main(String[] args) 
	{
	
		stu8 s =new stu8();
		
		s.set_regno(1011);
		s.set_name("Name1");
		s.set_mark(98);
		
		System.out.println("RegNo:"+s.get_regno());
		System.out.println("Name:"+s.get_name());
		System.out.println("Mark:"+s.get_mark());
		
	}

}
