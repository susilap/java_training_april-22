package basics;

public class default_demo {

	public static void main(String[] args) 
	{
		customer obj =new customer(101,"Arjun","chennai");
		obj.display();
		
		obj.id=111;
		System.out.println(obj.id);
		customer.name="manju";
		System.out.println(customer.name);
		customer.address="Delhi";
		System.out.println(customer.address);
		
		System.out.println(obj.aadhar);
		//obj.aadhar=111869555554l;
		System.out.println(obj.aadhar);


		
		customer obj1 =new customer(102,"Anu","Bangalore");
		obj1.display();


	}

}
