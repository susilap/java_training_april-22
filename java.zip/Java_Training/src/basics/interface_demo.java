package basics;

interface bank2
{
	String PAN="GKTPS4323L";
	
	int roi();
	
	static void display()
	{
		System.out.println("Static method implementation");
	}
	
	default void show()
	{
		System.out.println("Default method implementation");
	}

}

class sbi2 implements bank2
{

	
	public int roi() {
	
		return 10;
	}
	
}

class icici2 implements bank2
{

	
	public int roi() {
	
		return 13;
	}
	
}

class hdfc2 implements bank2
{

	
	public int roi() {
	
		return 16;
	}
	
}

public class interface_demo {

	public static void main(String[] args)
	{
		
		sbi2 s =new sbi2();
		icici2 i =new icici2();
		hdfc2 h =new hdfc2();
		
		System.out.println("SBI INTEREST :"+s.roi());
		System.out.println("ICICI INTEREST :"+i.roi());
		System.out.println("HDFC INTEREST :"+h.roi());
		
		bank2.display();
		s.show();
		//bank2.PAN="fdfe222";
		System.out.println(bank2.PAN);


	}

}
