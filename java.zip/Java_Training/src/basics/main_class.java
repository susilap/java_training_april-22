package basics;

import java.util.Scanner;

class stuu
{
	int regno,m1,m2,m3,tot,avg;
	String name,result;
	
	void read_details()
	{
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the Regno");
		regno=s.nextInt();

		System.out.println("Enter the Name");
		name=s.next();
		
		System.out.println("Enter the Mark1");
		m1=s.nextInt();
		
		System.out.println("Enter the Mark2");
		m2=s.nextInt();
		
		System.out.println("Enter the Mark3");
		m3=s.nextInt();
	}
	
	void marksheet()
	{
		tot=m1+m2+m3;
		avg=tot/3;
		if(m1>=50 && m2>=50 && m3>=50)
		{
			result="pass";
		}
		else
			
		{
			result="fail";
		}
	}
	void display()
	{
		System.out.println("Student Details");
		System.out.println("Student Reg No:"+regno);
		System.out.println("Student Name:"+name);
		System.out.println(" Mark1:"+m1);
		System.out.println(" Mark2:"+m2);
		System.out.println(" Mark3:"+m3);
		System.out.println(" Total:"+regno);
		System.out.println("Average:"+avg);
		System.out.println("Result"+result);
	}

}

class emp extends stuu  //
{
	String name;
	int  emp_no;
	float salary,da,hra,pf,esi,tot_earnings,tot_deduction,gross_pay;
	void getdata()
	{
		Scanner s =new Scanner(System.in);
		
		System.out.println("Enter the Employee Name");
		 name =s.next();
		
		System.out.println("Enter the Employee Number");
		 emp_no =s.nextInt();
		
		System.out.println("Enter the Employee Salary");
		 salary =s.nextFloat();	
	}
	
	void calculate()
	{
		 da=salary*15/100;
		 hra=30*salary/100;
		
		 pf=12*salary/100;
		 esi=15*salary/100;
		 
		 tot_deduction =pf+esi;
		
		 tot_earnings=salary+da+hra;
		 
		 gross_pay=tot_earnings-tot_deduction;

	}
	
	void report()
	{
		System.out.println(" ==============================================================");
		System.out.println(" Employee Details");
		System.out.println(" ==============================================================");
		System.out.println(" Employee Number:"+emp_no);
		System.out.println(" Employee Name:"+name);
		System.out.println(" Employee Salary:"+salary);
		System.out.println(" Total Earnings:"+tot_earnings);
		System.out.println(" Total Deduction :"+tot_deduction);
		System.out.println(" Net Salary:"+gross_pay);
		System.out.println(" ==============================================================");
	}

}
public class main_class {

	public static void main(String[] args)
	{
		emp e =new emp();
		
		e.getdata();
		e.calculate();
		e.report();
		
		e.read_details();
		e.marksheet();
		e.display();

	}

}
