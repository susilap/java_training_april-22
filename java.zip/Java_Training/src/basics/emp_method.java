package basics;

import java.util.Scanner;

public class emp_method {
	String name;
	int  emp_no;
	float salary,da,hra,pf,esi,tot_earnings,tot_deduction,gross_pay;
	void getdata()
	{
		Scanner s =new Scanner(System.in);
		
		System.out.println("Enter the Employee Name");
		 name =s.next();
		
		System.out.println("Enter the Employee Number");
		 emp_no =s.nextInt();
		
		System.out.println("Enter the Employee Salary");
		 salary =s.nextFloat();	
	}
	
	void calculate()
	{
		 da=salary*15/100;
		 hra=30*salary/100;
		
		 pf=12*salary/100;
		 esi=15*salary/100;
		 tot_deduction =pf+esi;
		
		 tot_earnings=salary+da+hra;
		 gross_pay=tot_earnings-tot_deduction;

	}
	
	void report()
	{
		System.out.println(" ==============================================================");
		System.out.println(" Employee Details");
		System.out.println(" ==============================================================");
		System.out.println(" Employee Number:"+emp_no);
		System.out.println(" Employee Name:"+name);
		System.out.println(" Employee Salary:"+salary);
		System.out.println(" Total Earnings:"+tot_earnings);
		System.out.println(" Total Deduction :"+tot_deduction);
		System.out.println(" Net Salary:"+gross_pay);
		System.out.println(" ==============================================================");

	}

	public static void main(String[] args) {
		emp_method e =new emp_method();
		emp_method e1 =new emp_method();

		
		e.getdata();
		e.calculate();
		e.report();

		e1.getdata();
		e1.calculate();
		e1.report();
		

	}

}
